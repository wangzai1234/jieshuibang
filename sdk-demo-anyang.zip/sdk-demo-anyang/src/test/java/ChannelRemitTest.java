/**
 * Created by jiashuai.bao on 2019-06-17.
 */
package test.java;



import com.sec.sdk.SecClient;
import com.sec.sdk.bean.BaseResponse;
import com.sec.sdk.bean.RemitBatchRequestDTO;
import com.sec.sdk.bean.RemitDetailRequestDTO;
import com.sec.sdk.constants.SecGatewayConstants;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 *
 *对应文档 5.1 银行卡打款申请 （渠道版商户适用，接口文档回标注标准版还是渠道版）
 *
 **/

public class ChannelRemitTest {

    /**
     * 商户私钥 请根据文档描述生成并妥善保管！
     * */
    String merPrivate = "MIIEvQIBADANBgkqhkiG9w0BAQEFAASCBKcwggSjAgEAAoIBAQCQKF5YMqxWkiJzer/HwjYwEZQwKJDqyDBJgAyTlI3FhY4UAJEz1X/ZJFAeZRGbc8G0RsPT23Zzx11GniZCm4m5DZPw5G5nCOhMPgCT7e/UopKLw8FzCLAWb5LH2t4uACRJ2+k8MaAJgnqMbL7vgam+ED1cOAwlP6+G+HCltqYBiCa3ux03qxaiCEHFc2NuGUzGB3mRkB+r2J6JSCSgS3PignHgdvFFFZRYYJQgPMeUXYrrWkq0EJ4Ule7Mre2VNUSHSt0VuswWawUlKVoF2pUTiFTs3ULaqqrd9bbqMQEbQOxLsx8IaP1sXL/m8GFIP04Mv6ug9gvDo3vngmmRFBm7AgMBAAECggEAKstBDo+kZ2KkRYG38tXtfiGJyy4PrxLUes0/boQX/f3iqn9sm2WSuWQ1QICiVHJtm1Wyhm7M4Bvbzb3e/8DqhnvIYid9uqqDQzbYtxFYM9g7BrCK+donY9GlUhzf/ene2+ojd9IHfysztAIIQFNOj3SEsp6UxG3+bmPMFPV+nE9YQ2EDA8I06DpZAE4EuBcQIbO/IK9jU5t3CQpaV1Pjc2Bw1WSqBGzhLf6eivNGkBq+eZXQbgUYivNo+Cvzu30GhJsU7ELQ3/qSDV3daBpGs+Ng31WvvPHKtX0hlx2iu8XFhBrtpwyz/Azo4w/e9Dga6jJ8QyKfp6uLzloxP9fiqQKBgQD0f0fNr3HPYktmnR96f9yFxMa1V48Cv0GfdzW6mNaLRPj5hjtGP2R0JmJgNzLmwYfR2uYQ4hTRq1BOUUFrAonrXozYu06F4RJiWv+D+eOD6wWXU6rzKktA/xqo23ov7DK0/EHbUHe+thYY2+93pM67eJZehquuOJhZt1XC6HXqNQKBgQCW8JncL+aHSTjBEZOLXyrJY8J5CGck9tEYni3lvK/Ic8ynr6Aq9jtf+f4koC6VePvtgo+zZPv2Trf2dzoxZFP5rBisL6/1zI8FFcYOwrcr66103JL/37ky9MRNfd/wjGiwyrggahQTRAIi++M2quL/bCdtNvAt574zyFO1/OjyLwKBgQDHWjB1qSOm8IKCPIK6Ix7vgy5yFd5pYwBiwZRxfMUR8T8AVU5nTLDfc5yqztcWB55yoYUNJwnKm2BzOxWX5w4Fd6Zn4PF5f7a5s3C7bzjvCuYYKQQuGMIbUOWv4KSUBoahwzz/UXERcu45frqWVy6o9P3GPRAmkcbHABFRRrE+MQKBgG9j/lglrX4Xhl/NRdKsF9pp2cISdnQsBeGiEoMhvaQz+Uui65PpBaZtyqVi5R4AHAOKv9wHYX7DVzX3hSWgQezWmZqw0q2WGdIJ4JFSF3W9RtQgWAenJni5dAkwJMzUAgq+gCXDwy74mI8SzvqwIDeZrHsH+TYXeSGj7Es46vyXAoGAfGeN0X9fnSggKxfFFDpmWpx3nWJVRSJ/uLDo9ltoA73SVMCO6FldL/+fiFin6Su9314IsHhqm7jauZl7kJ7KkGBUwI5j3J0r0K3wY7mpeWiZUezv3aktZRoTk6NVCal4zjSQOBCy1wDVVWUjvXEHNG74m5MWVuHH68DKHmoxmO8=";


   
    public void httpTest() throws Exception{

        //商户应用ID
        String appId = "941637b516934f9099401ffd780d6161";

        SecClient secClient = new SecClient(SecGatewayConstants.SERVER_URL,"settle.remit.api.channelPay", appId,merPrivate,"001","2013-01-01 08:08:08",20000,20000);

        //业务参数构建
        RemitBatchRequestDTO remitBatchRequestDTO = new RemitBatchRequestDTO();

        remitBatchRequestDTO.setCustBatchNo(UUID.randomUUID().toString().replace("-",""));
        remitBatchRequestDTO.setBatchNum(2);
        //new BigDecimal 时请写string类型 防止精度丢失
        remitBatchRequestDTO.setBatchAmt(new BigDecimal("100"));
        remitBatchRequestDTO.setServerCallbackUrl("");

        List<RemitDetailRequestDTO> list = new ArrayList<RemitDetailRequestDTO>();
        RemitDetailRequestDTO detail_1 = new RemitDetailRequestDTO();
        detail_1.setCustNo(appId);
        String cust_1 = UUID.randomUUID().toString().replace("-","");
        System.out.println("cust_1  :  "+cust_1);
        detail_1.setCustOrderNo(cust_1);
        //new BigDecimal 时请写string类型 防止精度丢失
        detail_1.setOrderAmt(new BigDecimal("40"));
        detail_1.setRecvCustName("");
        detail_1.setRecvMobile("");
        detail_1.setRecvIdType("");
        detail_1.setRecvIdNo("");
        detail_1.setRecvCardNo("");
        detail_1.setRecvBankName("");
        list.add(detail_1);

        RemitDetailRequestDTO detail_2 = new RemitDetailRequestDTO();
        detail_2.setCustNo(appId);
        String cust_2 = UUID.randomUUID().toString().replace("-","");
        System.out.println("cust_2  :  "+cust_2);
        detail_2.setCustOrderNo(cust_2);
        //new BigDecimal 时请写string类型 防止精度丢失
        detail_2.setOrderAmt(new BigDecimal("60"));
        detail_2.setRecvCustName("");
        detail_2.setRecvMobile("");
        detail_2.setRecvIdType("");
        detail_2.setRecvIdNo("");
        detail_2.setRecvCardNo("");
        detail_2.setRecvBankName("");
        list.add(detail_2);

        remitBatchRequestDTO.setRemitDetailList(list);

        BaseResponse responseDTO = secClient.excute(remitBatchRequestDTO);
        System.out.println(responseDTO.toString());
        System.out.println(responseDTO.getResponse());

    }

    /*public static void main(String[] args)  throws Exception{
        Map<String ,String> params = new HashMap();
        params.put("app_id","YX0000000000001"); //可以放入请求头中
        params.put("method","settle.remit.api.payment");
        params.put("sign_type","RSA2");
        params.put("timestamp","2013-01-01 08:08:08"); //毫秒
        params.put("version","1.0");
        params.put("merchant_request_no","10000000000");
        TestDTO testDTO = new TestDTO();
        testDTO.setMany("10086");
        testDTO.setOrderNo("这是个订单号");

        List<EntyDTO> list = new ArrayList<>();
        EntyDTO entyDTO = new EntyDTO();
        entyDTO.setTest1("1");
        entyDTO.setTest2("2");
        list.add(entyDTO);
        testDTO.setList(list);
        params.put("biz_content", JsonUtils.ObjectTojson(testDTO));//JSON 可加密
        //参数进行RES签名
        String signa = SecSignature.rsaSign(params, merPrivate,"UTF-8","RSA2");

        System.out.println(signa);

        params.put("sign",signa);

        String resp = WebUtils.doPost("http://127.0.0.1:8003/secopenplatfrom/sec/gateway",params,"UTF-8",100000,100000,null,0);

        System.out.println(resp);
    }*/
}
