package test.java;



import com.sec.sdk.SecClient;
import com.sec.sdk.bean.BaseResponse;
import com.sec.sdk.bean.CustCheckAccountRequestDTO;
import com.sec.sdk.constants.SecGatewayConstants;

/**
 * 5.4 商户成功付款对账文件下载
 **/

public class CustCheckSuccessAccountTest {

    /**
     * 商户私钥 请根据文档描述生成并妥善保管！
     * */
    static String merPrivate = "MIIEvQIBADANBgkqhkiG9w0BAQEFAASCBKcwggSjAgEAAoIBAQCQKF5YMqxWkiJzer/HwjYwEZQwKJDqyDBJgAyTlI3FhY4UAJEz1X/ZJFAeZRGbc8G0RsPT23Zzx11GniZCm4m5DZPw5G5nCOhMPgCT7e/UopKLw8FzCLAWb5LH2t4uACRJ2+k8MaAJgnqMbL7vgam+ED1cOAwlP6+G+HCltqYBiCa3ux03qxaiCEHFc2NuGUzGB3mRkB+r2J6JSCSgS3PignHgdvFFFZRYYJQgPMeUXYrrWkq0EJ4Ule7Mre2VNUSHSt0VuswWawUlKVoF2pUTiFTs3ULaqqrd9bbqMQEbQOxLsx8IaP1sXL/m8GFIP04Mv6ug9gvDo3vngmmRFBm7AgMBAAECggEAKstBDo+kZ2KkRYG38tXtfiGJyy4PrxLUes0/boQX/f3iqn9sm2WSuWQ1QICiVHJtm1Wyhm7M4Bvbzb3e/8DqhnvIYid9uqqDQzbYtxFYM9g7BrCK+donY9GlUhzf/ene2+ojd9IHfysztAIIQFNOj3SEsp6UxG3+bmPMFPV+nE9YQ2EDA8I06DpZAE4EuBcQIbO/IK9jU5t3CQpaV1Pjc2Bw1WSqBGzhLf6eivNGkBq+eZXQbgUYivNo+Cvzu30GhJsU7ELQ3/qSDV3daBpGs+Ng31WvvPHKtX0hlx2iu8XFhBrtpwyz/Azo4w/e9Dga6jJ8QyKfp6uLzloxP9fiqQKBgQD0f0fNr3HPYktmnR96f9yFxMa1V48Cv0GfdzW6mNaLRPj5hjtGP2R0JmJgNzLmwYfR2uYQ4hTRq1BOUUFrAonrXozYu06F4RJiWv+D+eOD6wWXU6rzKktA/xqo23ov7DK0/EHbUHe+thYY2+93pM67eJZehquuOJhZt1XC6HXqNQKBgQCW8JncL+aHSTjBEZOLXyrJY8J5CGck9tEYni3lvK/Ic8ynr6Aq9jtf+f4koC6VePvtgo+zZPv2Trf2dzoxZFP5rBisL6/1zI8FFcYOwrcr66103JL/37ky9MRNfd/wjGiwyrggahQTRAIi++M2quL/bCdtNvAt574zyFO1/OjyLwKBgQDHWjB1qSOm8IKCPIK6Ix7vgy5yFd5pYwBiwZRxfMUR8T8AVU5nTLDfc5yqztcWB55yoYUNJwnKm2BzOxWX5w4Fd6Zn4PF5f7a5s3C7bzjvCuYYKQQuGMIbUOWv4KSUBoahwzz/UXERcu45frqWVy6o9P3GPRAmkcbHABFRRrE+MQKBgG9j/lglrX4Xhl/NRdKsF9pp2cISdnQsBeGiEoMhvaQz+Uui65PpBaZtyqVi5R4AHAOKv9wHYX7DVzX3hSWgQezWmZqw0q2WGdIJ4JFSF3W9RtQgWAenJni5dAkwJMzUAgq+gCXDwy74mI8SzvqwIDeZrHsH+TYXeSGj7Es46vyXAoGAfGeN0X9fnSggKxfFFDpmWpx3nWJVRSJ/uLDo9ltoA73SVMCO6FldL/+fiFin6Su9314IsHhqm7jauZl7kJ7KkGBUwI5j3J0r0K3wY7mpeWiZUezv3aktZRoTk6NVCal4zjSQOBCy1wDVVWUjvXEHNG74m5MWVuHH68DKHmoxmO8=";

   
    public static void httpTest() throws Exception{

        //商户应用ID
        String appId = "941637b516934f9099401ffd780d6161";

        SecClient secClient = new SecClient(SecGatewayConstants.SERVER_URL,"settle.cust.api.checksuccess", appId,merPrivate,"001","2013-01-01 08:08:08",20000,20000);

        //业务参数构建
        CustCheckAccountRequestDTO requestDTO = new CustCheckAccountRequestDTO();
        //requestDTO.setCheckDate("9928019f9dd74c7880308316ff8cbf04");
        
        requestDTO.setCheckDate("2019-07-18");
        BaseResponse responseDTO = secClient.excute(requestDTO);
        System.out.println(responseDTO.toString());
        System.out.println(responseDTO.getResponse());
    }
    public static void main(String[] args) {
		try {
			httpTest();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
