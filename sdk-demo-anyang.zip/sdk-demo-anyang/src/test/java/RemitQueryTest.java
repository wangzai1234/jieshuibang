/**
 * Created by jiashuai.bao on 2019-06-17.
 */
package test.java;



import com.sec.sdk.SecClient;
import com.sec.sdk.bean.BaseResponse;
import com.sec.sdk.bean.RemitQueryRequestDTO;
import com.sec.sdk.constants.SecGatewayConstants;

/**
 * 对应文档 5.2 付款订单查询
 **/

public class RemitQueryTest {

    /**
     * 商户私钥 请根据文档描述生成并妥善保管！
     * */
    static String merPrivate = "MIIEvgIBADANBgkqhkiG9w0BAQEFAASCBKgwggSkAgEAAoIBAQCQeJEjHQCN6vvGhjEf9u+/+8CRufD7Et9gImrZPVZLOxrEUu+DY2ps/7KsKNMGsavR6T1ohCFxZ7WFRcQdqPpjSyEVUVYO+qSx3JA6pUf1p9RBjhyHAwRge6SNiXBikCZxbikRqs4FYAUxGWuHN01fmuUwPlx2fPXO54Mu/+Tb03cMRuNBcmvlRLRLfyXI1uNOhCNWWvkfoY/nLeAw9FHlhtllNN83Rl6rbqXZo7d0r/COEQBJC07wCCQFJWJO/50m54MnsjWQhRoieI3ht5pgBui8un2/T3xRM8o23yYAV1LyXhX+9VdHMgIM8OpjfYlTlhC2UlZNv7aqhgqbiMZfAgMBAAECggEAS9vC+dkErYAxa/CSYuJayUf7uYkVDADA4c2wpRkb8qy6RVP3B9pvy4QH4XYeOGmaesIpyHN4y/9UxQH5FEniD7knSfZHZd4eFHZoFSMsQcU6IqHoQMxIxBCoOtlr9ZUTWoQpdGlnfFMK5tkeKQXUztqadVaJXn4G4/mUXF1pYjNBUq1M163bN75lmzMaKU6Yh4tPsv8ZvqN7hckwmLsRaR9/dDDy978pVWN9gzIZcve9/Y26s5eSh2Oa0lnx+VvWaDDxZqUEi2qVrrxsoQFFZ+giDuYySG3oSH8BFwTdYfsJoE4CdjqnivukEasZUt/SMjPL/pYQpijuSqKaN2jOoQKBgQDENJDeS3IyzNTLyRECIaB93COZE/0O1edF50qSwiHOUjlirKKbK5IAcuzzN0waDJJxPQkJaCbOomXkTKDFHTMiJd31iR9vDhM3NjDLjz0S9bh7Lcl7nSDA1oMcmQXjhPnsmjV2p5Mfj5NXBM2mIT4zqZJmhg8YtvP3/xyMhgSFbQKBgQC8f9GjM6MuT75Wes6hnJ0DxKgU6PSwTu0Re0FgZ1N3E3Whqaj6COQ9N09qob//csJnYdiPOY082gqex7A8R+yt6w07MggGN1gyqX1i0jYouDLq9jnvIQVGhCDhWVz2IkTiBQUpQ3fHQM5Q8opSpYIpOMYcYN7Q8cBfzqrkZ1N3ewKBgQCOBfrjXjtwuEJErOup3kt9L295LDXemkmJmS2q4+lynqQ5X/toVPafapFIULu+k2EhpOu4qnKE2prk0e8CH+vWiRCM3lAppEeWjJxvjOTJp6J9T5xr5UZDMEPB3KadlbEPamTO2eguTVB7CdgOrDuJS/LUUa/11ODun/S7Z3s4VQKBgQCubEwtCyQtP2buGPdJPmVgTkIGD0YUOwRNT9NABHyMS/pmXFra+w1Pw/V9wyypkKRpC3ZbmbKio1R+dmMSdK+Cg2Ub6IDaV64KOyGmJsQsy716A9u59cEu7iaKv6kwrKc2ydRryV11h/chmjz6muIliL5xFgY4K+uJ++/QJ/hpLwKBgBFVBs80VDfTZHepFtNz+IT38qviYlfg+3vmnxsM2syUfpvTg2WjdIvwmmxgGZvTJRn4ZLmWJ2A3wWLiSzLe4pHszkOhUX2kuhUhLrmt0EOqQZxE3YNZjWpTPxDBETFnNgvgPQ2s6AhNbadOn/EeiOOvVANqW7NaZyizve6lcq9L";

    public static void httpTest() throws Exception{

        //商户应用ID
        String appId = "941637b516934f9099401ffd780d6161";

        SecClient secClient = new SecClient(SecGatewayConstants.SERVER_URL,"settle.remit.api.query", appId,merPrivate,"RO1185006875939176448","2019-01-01 08:08:08",20000,20000);

        //业务参数构建
        RemitQueryRequestDTO requestDTO = new RemitQueryRequestDTO();
        requestDTO.setCustBatchNo("4d3f2a458aa443639d386a1af00d41e5");

        BaseResponse responseDTO = secClient.excute(requestDTO);
        System.out.println(responseDTO.toString());
        System.out.println(responseDTO.getResponse());
    }
    public static void main(String[] args) {
    	try {
			httpTest();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
