/**
 * Created by jiashuai.bao on 2019-06-17.
 */

package test.java;


import com.sec.sdk.SecClient;
import com.sec.sdk.bean.BaseResponse;
import com.sec.sdk.bean.RemitBatchRequestDTO;
import com.sec.sdk.bean.RemitDetailRequestDTO;
import com.sec.sdk.constants.SecGatewayConstants;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 *
 * 对应文档 5.1 付款申请 （标准版商户适用，接口文档回标注标准版还是渠道版）
 *
 **/

public class RemitApplyTest {
	public static void main(String[] args)  {
		try {
			httpTest();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

    /**
     * 商户私钥 请根据文档描述生成并妥善保管！
     * */
    static String merPrivate = "MIIEvAIBADANBgkqhkiG9w0BAQEFAASCBKYwggSiAgEAAoIBAQCtD4DbgPrkGGG9hCoZfT2N23/tHvOneyCxgurf8tJghb3mKRjiiNhC7nh9CTmbsU4IatENfnbfZIsVWCIoZ6hkM85B8g+xwv3LDju3AwFyZ91prsgfjaLy9aK0CRPIFqxKbrqDZA//ij5CDYL3TR31TpyqHklHELX02u+jZlZqwnzD8G/yXzZdVRe25d6OuUSxMckVUdNREKANcHkjx1B/qhPHDIhOD0pJdMTqthH9lgifVMlmmk1YAl80A82wNwniuZkxbXAs3QGg1h30u2BrVQ0H5ZGz4HUidGXE5q3vH5UIyNouurYDjs6RiB4HiZpsj0gDyZHMcskpAZ721iKFAgMBAAECggEAVnaDc6eaMfG4i34Hppp68W/0Fx06sLeEmwuEm4Tu9Mh9Gwv3Yd7q5W3NhvLf9Fh+Wxg7ABnp/Cx4jJ5u2m8Ho6B6cVol2zNHp3aiAQqgY29fINjxJUqXWfm9Y2ORnYsuYzW1O8X3dD22Yzvq7fF6gT/YZ+ofxECmGAJ2bdXIYSecCu8fKigH3ZzITjPNwonl9EoFi/qi4w3uAReV4zBx3yGdbs4H7h+JLpKh8bbn4msp12S+GdHGDAe4tDlSJnNA39JILa4NzMsXSo6/Atl46VNwAG1+Qj8sX9KW9cZFpMMRWgG4nWhXtZPdcnNv4M01tgUXvtDvHes6HaqI0s9+oQKBgQDwehE9XHfpiPtKc7/eA0x55ucTg++NTVPumsdZwHfqJAMHheRTqbBnQEeM6dzXyZ9Tp+p7eOUO7PidoQSEFnNIQtJw0cI7GeP3YAjlUkQyU5Xqt0WFkBUewM7x71wkvzIQ+GFa8TL1KPY/mmZPAo++2d5ospOe0VcjH4wty34cvQKBgQC4O14JKUGwcIUB3XPr1rItWysNtpktAXieCNNFqTxkhiRfmpi/Jx19pyhyCX03CLIpDvm89ETGuA1CylgMMDpWIsJnMgPTbDSvu9MsqO96EP0dxAGX0ZhrMbgp7GCIJagWRs/6Z1QAgzBWj3vL7+WQlZXUgUf6ouW7b9oj243NaQKBgEf9Etoeq1sDAc8Y9ZAdxrAbeoNyFK1lP8IHHbR1lLBIFYwT/fU5sDBIouLBQ7ZpikO92ckauN+N+yMdB8APBHXWYy8Y7B9LMd5lJmSYCwhR02hPcwV3y4rIR2tPr3LktbU01dgmqo2PtJ/3tbbjWmrUx+rpwp1hp8dA83LmHxu1AoGAJaHi3IYz5+GkGbRtuG/7p24nBj8VXO8e/1EYLvOZ5YLNLUY8C1fnG0Ko7Vpo3HQHSIHJm8JdxiXUd58zixHS6MNi6Id75pUE0hzQzx+XA10zBwCBvsxOkR7v2ohxU341ro86bpDqxMwHdLcMd6UCRJ15pJXf6R+bQ8VeTtLLTXkCgYARfbIWqP8qXuu6OHfbZ8MErV8WZ/f9Ssbr4CakfIWI/Xn9U2A44q/JPIdS4Df/nJldBDhASIjaGuvbxiYO6SM2m6mTFcJCoMG3WeSUruwfk0Qnw4xN9BwfVaAL0BvMzskjUXRHWMmsICwaXtOmDZy6FMee21DGsn0L0gu5ioU0OA==";

    
    public static void httpTest() throws Exception{

        //商户应用ID
        String appId = "101910291301";

        SecClient secClient = new SecClient(SecGatewayConstants.SERVER_URL,"settle.remit.api.payment", appId,merPrivate,"001","2013-01-01 08:08:08",20000,20000);

        //业务参数构建
        RemitBatchRequestDTO remitBatchRequestDTO = new RemitBatchRequestDTO();

        remitBatchRequestDTO.setCustBatchNo(UUID.randomUUID().toString().replace("-",""));
        remitBatchRequestDTO.setBatchNum(1);
        //new BigDecimal 时请写string类型 防止精度丢失
        remitBatchRequestDTO.setBatchAmt(new BigDecimal("1.22"));
        remitBatchRequestDTO.setServerCallbackUrl("http://39.97.110.167/sop/callBack");
        remitBatchRequestDTO.setRecvType("ALIPAY");
        String w = remitBatchRequestDTO.toString();
        System.out.println("===="+w);
        List<RemitDetailRequestDTO> list = new ArrayList<RemitDetailRequestDTO>();
        RemitDetailRequestDTO detail_1 = new RemitDetailRequestDTO();
        detail_1.setCustNo(appId);
        String cust_1 = UUID.randomUUID().toString().replace("-","");
        System.out.println("cust_1  :  "+cust_1);
        detail_1.setCustOrderNo(cust_1);
        System.out.println("cust_1  :  "+cust_1);
        //new BigDecimal 时请写string类型 防止精度丢失
        detail_1.setOrderAmt(new BigDecimal("1.22"));
        detail_1.setRecvCustName("杨磊");
        detail_1.setRecvIdType("IDENTITY");
        //detail_1.setRecvType("ALIPAY");
       //detail_1.setRecvMobile("18348501030");
        detail_1.setRecvIdNo("232126199802042910");
       // detail_1.setRecvCardNo("6214830191924777");
        detail_1.setRecvCardNo("18348501030");
        detail_1.setRecvBankName("支付宝");
        list.add(detail_1);

//        RemitDetailRequestDTO detail_2 = new RemitDetailRequestDTO();
//        detail_2.setCustNo(appId);
//        String cust_2 = UUID.randomUUID().toString().replace("-","");
//        System.out.println("cust_1  :  "+cust_2);
//        detail_2.setCustOrderNo(cust_1);
//        //new BigDecimal 时请写string类型 防止精度丢失
//        detail_2.setOrderAmt(new BigDecimal("20.02"));
//        detail_2.setRecvCustName("");
//        detail_2.setRecvMobile("");
//        detail_2.setRecvIdType("IDENTITY");
//        detail_2.setRecvIdNo("");
//        detail_2.setRecvCardNo("");
//        detail_2.setRecvBankName("");
//        list.add(detail_2);


        for(int i = 0 ; i < list.size() ; i++) {

            System.out.println(list.get(i));

        }

        remitBatchRequestDTO.setRemitDetailList(list);
        System.out.println();
        BaseResponse responseDTO = secClient.excute(remitBatchRequestDTO);
        System.out.println(responseDTO.toString());
        System.out.println(responseDTO.getResponse());

    }
		
}
